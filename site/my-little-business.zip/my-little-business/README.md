# GAE-word-fun
Daily word guessing game

Install and run on Google App Engine

Needs:
- scoreboard
- visually acceptable CSS for frontend
