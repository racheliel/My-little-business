$(function() {
	$('#start_game').on('click', function() {
		document.location.href = '/game';
	});
});